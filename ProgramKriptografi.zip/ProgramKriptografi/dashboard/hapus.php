<?php  
    include "../config.php";
    $id = $_GET['username'];
    $query = mysqli_query($connect, "DELETE FROM users WHERE username= '$id'");
    
?>