<?php
session_start();
include 'config.php';


$user = $_POST['username'];
$pass = $_POST['password'];

$query = "SELECT username,password, level FROM users WHERE username='$user' AND password=md5('$pass')";
$sql = mysqli_query($connect,$query);
$cek = mysqli_num_rows($sql);
$fetchdata = mysqli_fetch_array($sql);
if ($cek > 0) {
$level = $fetchdata['level'];
if ($level =='1') {
		$_SESSION['username']= $user;
		$_SESSION['level']= $level;
			header("location: dashboard/index.php");
		} else if ($level == '0') {
		$_SESSION['username']= $user;
		$_SESSION['level']= $level;
			header("location: agen/index.php");
	 } else {
		echo "<script language=\"JavaScript\">\n";
		echo "alert('Username atau Password Salah!');\n";
		echo "window.location='index.php'";
		echo "</script>";
	} 
	}
?>
